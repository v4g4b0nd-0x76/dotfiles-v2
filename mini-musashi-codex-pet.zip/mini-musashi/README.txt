Mini Musashi Codex Pet

To import on another device:
1. Unzip this archive.
2. Copy the folder named mini-musashi into:
   ~/.codex/pets/mini-musashi
3. Restart Codex if it is already open.

The pet requires both files:
- pet.json
- spritesheet.webp
